var TopicConnectionGraph = function($graph, graph_width, graph_height, center_x, center_y, offset_x, offset_y, sizes) {

};

TopicConnectionGraph.prototype = {

    runner: function(images, topic_image) {

    },

    create_image: function(src, x, y, s) {

    }

};
