var TopicConnectionGraph = function($graph, graph_width, graph_height, center_x, center_y, offset_x, offset_y, sizes) {

    var paper = Raphael($graph, graph_width, graph_height);
    this.r = paper;
    this.center_x = center_x || 125;
    this.center_y = center_y || 125;
    this.offset_x = offset_x || 35;
    this.offset_y = offset_y || 35;
    this.sizes = sizes || { 'small': 30, 'medium': 50, 'large': 70, 'xlarge': 100 };
    this.rotation = 3.14/2;
	this.$graph = $($graph);
	this.$module = this.$graph.parents('.SO-module');
};

TopicConnectionGraph.prototype = {

    runner: function(images, topic_image) {

    },

    create_image: function(src, x, y, s) {

    }

};
