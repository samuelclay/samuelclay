var TopicConnectionGraph = function($graph, graph_width, graph_height, center_x, center_y, offset_x, offset_y, sizes) {

    var paper = Raphael($graph, graph_width, graph_height);
    this.r = paper;
    this.center_x = center_x || 125;
    this.center_y = center_y || 125;
    this.offset_x = offset_x || 35;
    this.offset_y = offset_y || 35;
    this.sizes = sizes || { 'small': 30, 'medium': 50, 'large': 70, 'xlarge': 100 };
    this.rotation = 3.14/2;
	this.$graph = $($graph);
	this.$module = this.$graph.parents('.SO-module');
};

TopicConnectionGraph.prototype = {

    runner: function(images, topic_image) {
        this.arc_step_size = 2*3.14 / images.length;

        topic_image['img_svg'] = this.create_image(topic_image['img'], this.center_x+this.offset_x, this.center_y+this.offset_y, this.sizes[topic_image['s']]);

    },

    create_image: function(src, x, y, s) {
        var radius = s / 2;
        var xCoor = x;
        var yCoor = y;
        var c_3_sw = (Math.sqrt(2) - 1) * radius;
        var c_2_sw = 3;
        var c_1_sw = 3;
        var c_3_r = radius + (.5*c_3_sw);
        var c_2_r = radius;
        var c_1_r = radius - 2;
        var color = '#C0C0C0';

        var heroImage = this.r.image(src, x-radius, y-radius, s, s);
        var c_3 = this.r.circle(xCoor, yCoor, c_3_r).attr({stroke: '#fff', 'stroke-width': c_3_sw });
        var c_2 = this.r.circle(xCoor, yCoor, c_2_r).attr({stroke: color, 'stroke-width': c_2_sw });
        var c_1 = this.r.circle(xCoor, yCoor, c_1_r).attr({stroke: '#fff', 'stroke-width': c_1_sw });
        c_2.insertAfter(c_1);

        var set = this.r.set();
        set.push(heroImage);
        set.push(c_2);
        set.push(c_1);

        return {img: heroImage, c_2: c_2, c_1: c_1, set: set};
    }

};
